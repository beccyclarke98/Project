package testing;

import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3IRSensor;
import lejos.robotics.RangeFinderAdapter;
import lejos.robotics.localization.PoseProvider;
import lejos.robotics.navigation.MovePilot;
import lejos.robotics.navigation.Pose;
import lejos.robotics.objectdetection.RangeFeatureDetector;
import lejos.utility.Delay;

		/*http://www.cs.ox.ac.uk/people/michael.wooldridge/teaching/robotics/lect05.pdf*/
		public class OccupancyGridMap
		{
			//GLOBAL VARIABLES
			int maxX,maxY = 0;
			int [][] Map;
			int [][] ObservationCounterOfEachCell; 
			boolean Forward15cm = true;
			public OdometryPoseProvider location = new OdometryPoseProvider(Test.pilot); 
			
			public OccupancyGridMap(int maxX, int maxY) 
			{
				this.maxX = maxX;
				this.maxY = maxY;
				
				Map = new int[maxX][maxY];
				ObservationCounterOfEachCell = new int[maxX][maxY];

				EV3IRSensor ir = new EV3IRSensor(SensorPort.S4); //Assign IR sensor to port S4.
		        RangeFeatureDetector detector = new RangeFeatureDetector(new RangeFinderAdapter(ir.getDistanceMode()), 300.0f, 500); //Make a range FEATURE detector with the range finder adaptor (Max Distance, Delay of 500ms(0.5 Seconds)
				location.getPose();
	        	int CurrentPoseX = (int) location.getPose().getX();  //Get the X position of the robot
	        	int CurrentPoseY = (int) location.getPose().getY();  //Get the Y position of the robot
				detector.setMaxDistance(15); //Set the max distance an object can be detected to 15cm infront of the robot
				
		        while(Forward15cm == true) //Movement
		        {	
		        	detector.scan(); //Try to detect an object
		        	Test.pilot.travel(15); //Move Forward 15
		        	Map[CurrentPoseX][CurrentPoseY] = CurrentPoseX + 1;
		        	Map[CurrentPoseX][CurrentPoseY] = CurrentPoseY + 1;
		        	detector.scan();
		        
			        if(detector.scan() == null) //IF IT DOESNT DETECT AN OBJECT
			        {
			        	detector.scan();
			        	
			        	//Increment	count of Observation when IR sensor has done a sca
			        	ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] = CurrentPoseX;
			        	ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] = CurrentPoseY;
			        	
			        	//Decreasing MAP
			        	Map[CurrentPoseX][CurrentPoseY] = CurrentPoseX - 1;
			        	Map[CurrentPoseX][CurrentPoseY] = CurrentPoseY - 1;
			        }
			        
			        if(detector.scan() !=null) //IF IT DOES DETECT AN OBJECT
			        {
			        	detector.scan();
			        	Test.pilot.rotate(35); //Rotate 35
			        	detector.scan();

			        	//Increment	count of Observation when IR sensor has done a scan	
			        	ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] = CurrentPoseX;
			        	ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] = CurrentPoseY;
			        	
			        	//Increasing MAP
			        	Map[CurrentPoseX][CurrentPoseY] = CurrentPoseX + 1;
			        	Map[CurrentPoseX][CurrentPoseY] = CurrentPoseY + 1;
			        }
					
			        if(ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] == 0) //If Observation Of Cell == 0 then we have no information on (x,y) � never observed it	
			        {
			        	ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] = CurrentPoseX = 0;
			        	ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] = CurrentPoseY = 0;
			        }
			        
			        if(Map[CurrentPoseX][CurrentPoseY] > 0 && ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] > 0) //If Map > 0 and C[x,y] > 0 then [x,y] is �probably	occupied�
			        {
			        	ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] = CurrentPoseX = 1;
			        	ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] = CurrentPoseY = 1;
			        }
			        
			        if(Map[CurrentPoseX][CurrentPoseY] < 0 && ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] > 0) //If Map < 0 and Observation > 0 then [x,y] is �probably unoccupied�	
			        {
			        	ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] = CurrentPoseX = 0;
			        	ObservationCounterOfEachCell[CurrentPoseX][CurrentPoseY] = CurrentPoseY = 0;
			        }
		      }
			}	//End Of OccupancyGrid Method	
	} //End Of OccupancyGrid Class