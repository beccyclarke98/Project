package testing;

import lejos.hardware.lcd.LCD;

//https://sourceforge.net/p/lejos/ev3/code/ci/master/tree/ev3classes/src/lejos/robotics/mapping/OccupancyGridMap.java#l19


//https://lejosnews.wordpress.com/2015/01/17/lejos-navigation-pilots/

import lejos.hardware.motor.Motor;
import lejos.hardware.port.SensorPort;
import lejos.hardware.sensor.EV3IRSensor;
import lejos.robotics.RangeFinderAdapter;
import lejos.robotics.SampleProvider;
import lejos.robotics.chassis.Chassis;
import lejos.robotics.chassis.Wheel;
import lejos.robotics.chassis.WheeledChassis;
import lejos.robotics.geometry.Point;
import lejos.robotics.localization.PoseProvider;
import lejos.robotics.navigation.Move;
import lejos.robotics.navigation.MoveListener;
import lejos.robotics.navigation.MovePilot;
import lejos.robotics.navigation.MoveProvider;
import lejos.robotics.navigation.Pose;
import lejos.robotics.objectdetection.RangeFeatureDetector;
import lejos.utility.Delay;

/*https://www.youtube.com/watch?v=PidhPVAGkdA&list=PL3c9v1f7NWPPxYvbvedCeXzKvqBciiTFn&index=29&t=0s*/			
public class Test 
{
		//GLOBAL VARIABLES
		public static MovePilot pilot;

		public static void main(String[] args)
		{ 
			//MOVE PILOT SETUP
			Wheel wheelL = WheeledChassis.modelWheel(Motor.C, 4).offset(-15); //Motor Used, Wheel Diameter, Track Size (30cm Wide)
			Wheel wheelR = WheeledChassis.modelWheel(Motor.B, 4).offset(15); //Motor Used, Wheel Diameter, Track Size (30cm Wide)
			Chassis chassis = new WheeledChassis(new Wheel[] { wheelL, wheelR }, WheeledChassis.TYPE_DIFFERENTIAL); 
			pilot = new MovePilot(chassis); //Make a new move pilot used the wheel chassis constructor
			//Setting Move Pilot Speed
			pilot.setLinearSpeed(10); //Set speed at which the robot will travel forward and backward 
			pilot.setAngularSpeed(10); //sets the rotation speed of the robot
		    LCD.drawString("Occupancy Grid", 0,4); //Set A LCD Message
		    OccupancyGridMap map = new OccupancyGridMap(1000, 1000);
		}
} //End Of Main Class