package testing;

import lejos.robotics.SampleProvider;
import lejos.robotics.geometry.Point;
import lejos.robotics.localization.PoseProvider;
import lejos.robotics.navigation.Move;
import lejos.robotics.navigation.MoveListener;
import lejos.robotics.navigation.MovePilot;
import lejos.robotics.navigation.MoveProvider;
import lejos.robotics.navigation.Pose;

	/*https://github.com/bdeneuter/lejos-ev3/blob/master/src/main/java/lejos/robotics/localization/OdometryPoseProvider.java*/
	public class OdometryPoseProvider implements PoseProvider, MoveListener, SampleProvider
	{
		private float x = 0;
		private float y = 0;
		private float heading = 0;
		boolean current = true;
		private float angle;
		private float distance;
		MoveProvider mp;

		OdometryPoseProvider(MoveProvider mp)
		{
			mp.addMoveListener(this);
		}
		
		public Pose getPose() 
		{
			if (!current) //If its not current get the Movement made and return X Y And Position robot is facing
		    {
		      updatePose(mp.getMovement()); 
		    }
		    return new Pose(x, y, heading);
		}
		
		@Override
		public int sampleSize() 
		{
			return 3; //Return X Y and Heading
		}

		@Override
		public void fetchSample(float[] sample, int offset) 
		{
			//Get The Samples
			if (!current)
		    {
		      updatePose(mp.getMovement());
		    }
		    sample[offset+0] = x;
		    sample[offset+1] = y;
		    sample[offset+2] = heading;
		}

		@Override
		public void moveStarted(Move move, MoveProvider mp)
		{
			//If a move started then its not the current position, used to measure difference
			angle = 0;
		    distance = 0;
		    current = false;
		    this.mp = mp;
		}

		@Override
		public void moveStopped(Move move, MoveProvider mp) 
		{
			//If a move stoped used to measure difference between stopped and start position
			 updatePose(move);
		}
		
		 private synchronized  void  updatePose(Move event)
		  {
		    float angleTurned = event.getAngleTurned() - angle;
		    float distanceTravelled = event.getDistanceTraveled() - distance;
		    double doublex = 0, doubley = 0;
		    double headingRadius = (Math.toRadians(heading));

		    if (event.getMoveType() == Move.MoveType.TRAVEL || Math.abs(angle)<0.2f) //If Move Type is Straight Line
		    {
		      doublex = (distanceTravelled) * (float) Math.cos(headingRadius);
		      doubley = (distanceTravelled) * (float) Math.sin(headingRadius);
		    }
		    
		    else if(event.getMoveType() == Move.MoveType.ARC) //If Move Type Is Rotation
		    {
		      double turnRadius = Math.toRadians(angle);
		      double radius = distanceTravelled / turnRadius;
		      doubley = radius * (Math.cos(headingRadius) - Math.cos(headingRadius + turnRadius));
		      doublex = radius * (Math.sin(headingRadius + turnRadius) - Math.sin(headingRadius));
		    }
		    
		    x += doublex;
		    y += doubley;
		    
		    angle = event.getAngleTurned(); //Angle Turned
		    distance = event.getDistanceTraveled(); //Distance Travelled
		    current = !event.isMoving(); //It Will be current if the robot isnt moving
		  }

		@Override
		public void setPose(Pose aPose) 
		{
			 setPosition(aPose.getLocation()); //CURRENT LOCATION
			 setHeading(aPose.getHeading()); //(direction angle) of the Pose
		}
		
		
		private void setHeading(float heading)
		 {
		    this.heading = heading; //(direction angle) of the Pose
		    current = true; //IS THIS THE CURRENT LOCATION OF ROBOT - YES
		 }
		
		private void setPosition(Point p)
		  {
		    x = p.x; //- X CORDINATE OF POINT
		    y = p.y; //- Y CORDINATE OF POINT
		    current = true; //IS THIS THE CURRENT LOCATION OF ROBOT - YES
		  }
	}
